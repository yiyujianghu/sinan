# -*-conding:utf-8-*-
# Base Information:
# @author:      yiyujianghu
# @project:     <sinan>
# @file:        __init__.py.py
# @time:        2020/8/5 8:38 下午

"""
Notes:...
"""

from sinan.date_num_parser import DateNumParser as Sinan

__all__ = ["Sinan"]